package com.example.touchapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
